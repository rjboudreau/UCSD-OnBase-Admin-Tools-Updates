# Version 0.3.6

AD Groups now clears the checked group rows automatically after a
successful membership apply. The selected people stay in the working set
so you can verify the result immediately, but the completed groups no
longer look like a new staged selection.

This release also points the in-app updater at the production update
feed, so future releases can be delivered without entering a feed path.
