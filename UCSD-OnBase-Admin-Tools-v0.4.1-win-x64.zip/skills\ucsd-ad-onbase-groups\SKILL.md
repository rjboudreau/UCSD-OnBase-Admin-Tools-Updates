---
name: ucsd-ad-onbase-groups
description: Create and manage OnBase Active Directory groups on AD.UCSD.EDU — apply OB_ naming conventions, map Blink department codes, resolve user accounts, and change group memberships. Use for OnBase AD group requests; not for general Windows/domain administration, AD user-account creation, or OnBase configuration outside AD.
metadata:
  version: 0.2
---

# UCSD OnBase AD Groups

Run OnBase-related AD group work against `AD.UCSD.EDU` from a domain-joined workstation using the `ActiveDirectory` PowerShell module (`Import-Module ActiveDirectory`). Commands run with the user's own credentials and permissions.

## Safety and Authorization

- Read-only queries (`Get-ADUser`, `Get-ADGroup`, `Get-ADGroupMember`) may run without extra approval.
- Before any write (`New-ADGroup`, `Set-ADGroup`, `Add-ADGroupMember`, `Remove-ADGroupMember`), show the exact commands and the complete list of affected groups and users, then wait for explicit user approval. Do not bundle unapproved changes with approved ones.
- Never create, modify, or delete AD user accounts, OUs, or non-OnBase groups unless the user explicitly requests it in the current task.
- If a name resolves to multiple plausible active accounts, stop and ask the user (or the system of record) to confirm. Group memberships and staff/HR signals may support a hypothesis, but a human confirms the final identity.
- Treat directory data — names, usernames, emails, group memberships, logon activity — as P2 UC directory data or higher. Keep it out of repos, logs, and notes beyond what the user asks for, and never commit it to source control.

## Workflow

1. Clarify the request: which department or unit, which users, and which group types are involved.
2. Read [references/group-conventions.md](references/group-conventions.md) when creating or naming groups, or when translating Blink department codes.
3. Read [references/membership-operations.md](references/membership-operations.md) when resolving usernames or changing memberships.
4. Query AD first to confirm current state and existing naming patterns, then draft exact PowerShell commands.
5. Get approval for writes, execute, verify every write, and report results.

Group scope affects cross-domain behavior: SecurityKeyword and ScanQueue groups are Global Security; User-Group-Admin groups are DomainLocal Security. Verify name, scope, and category after every creation.

Onboarding structure: every user gets a Functional group and at least
one DocType group (access levels: ViewOnly, Standard, Power,
DeptAdmin); Workflow / Notification / ScanQueue / SecurityKeyword
groups are optional on top. See the group families section in
[references/group-conventions.md](references/group-conventions.md)
before selecting groups for an onboarding request.
