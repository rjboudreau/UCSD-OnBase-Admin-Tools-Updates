# Reference Layers

Nothing large is pasted into prompts; read these on demand.

| Question | Layer | Location |
| --- | --- | --- |
| Which script interface / hook signature? | API catalog `SCRIPT-HOOKS.md` | `%LOCALAPPDATA%\UCSD OnBase Admin Tools\unity-api-catalog\SCRIPT-HOOKS.md` |
| Exact member signatures and XML docs for a type | API catalog index and type pages | Same directory: `INDEX.md`, `types/<namespace>/<Type>.md`, `catalog.json` |
| SDK lifecycle, patterns, concurrency, diagnostics, input contracts | Bundled SDK guide | `references/sdk-guide.md` in this skill |
| Document, keyword, queue, status, or field names | The brief's config dictionary | The `BRIEF.md` the prompt points at |
| Available imported assemblies / script libraries and versions | UCSD Reference Catalog (carried in the brief) | Brief; seed lives in the source repo's `docs/design/unity-scripts-assistant.md` |
| Studio click-paths, Add Reference tabs, publish/activate flow, common admin mistakes | Studio guide | `references/studio-guide.md` in this skill |

How to use each layer:

- **API catalog first** for any `Hyland.Unity.*` API question. The catalog is
  generated from the installed Studio assemblies, so it is version-matched and
  outranks every narrative page.
- **Bundled SDK guide** for lifecycle, common patterns, concurrency, and
  diagnostics. It is installed with this skill; no separate SDK-docs layer is
  required.
- **Brief** for every configuration name. Never take a document-type,
  keyword, queue, or field name from an example script or doc page - environments
  differ.
- **Reference catalog** for what exists before adding dependencies. Prefer
  maintained in-house libraries over reinventing. Confirm exact versions in
  Studio before writing them into the runbook.
- **Studio guide** for anything about the admin's screens. Where a step is
  marked NEEDS SCREENSHOT, describe it from the admin's screenshots rather than
  guessing menu labels.

Missing-layer behavior:

- **API catalog missing** - do NOT draft from memory; tell the admin to generate
  it from their OnBase Studio install (the Admin App does this on first use).
- **Brief missing required config names** - ask; never substitute.
