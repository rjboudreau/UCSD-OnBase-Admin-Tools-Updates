# Username Resolution and Membership Operations

## Resolve Usernames

Start with a surname search and inspect candidates:

```powershell
Get-ADUser -Filter "Surname -eq 'Lastname'" -Properties DisplayName, mail, GivenName, Surname
```

For ambiguous or unexpected matches, inspect more properties:

```powershell
Get-ADUser -Identity candidate -Properties DisplayName, mail, Enabled, whenCreated, lastLogonTimestamp, MemberOf
```

- Use the `MemberOf` property for group signals. Avoid `Get-ADPrincipalGroupMembership`, which can fail with authentication errors in this environment.
- Group memberships (staff vs. student groups, HR-related groups) help rank candidates but never prove identity.
- If two or more accounts are enabled and plausibly the same person, list them with display names and last-logon dates and ask the user to confirm. Do not add an unconfirmed account to any group.

## Add Members

```powershell
Add-ADGroupMember -Identity "OB_SecurityKeyword_X_HR_VCAA_CDB" -Members @('user1','user2')
```

Add each user to every group named in the approved request. Batch multiple users per group in one command, but keep each group as a separate command so failures are attributable.

## Remove Members

```powershell
Remove-ADGroupMember -Identity "OB_SecurityKeyword_X_HR_VCAA_CDB" -Members @('user1') -Confirm:False
```

Only remove members the user explicitly named. `-Confirm:False` is acceptable only after the user has approved the exact removal.

## Review Current Memberships

```powershell
Get-ADUser -Identity username -Properties MemberOf
Get-ADGroupMember -Identity "OB_SecurityKeyword_X_HR_VCAA_CDB"
```

## Verify Results

After writes, verify each affected group's membership and count:

```powershell
Get-ADGroupMember -Identity "OB_SecurityKeyword_X_HR_VCAA_CDB" | Select-Object sAMAccountName, Name
(Get-ADGroupMember -Identity "OB_SecurityKeyword_X_HR_VCAA_CDB").Count
```

For multi-group onboarding, verify every user appears in every expected group and report the totals (for example, 8 users × 3 groups = 24 memberships) before calling the task complete.
