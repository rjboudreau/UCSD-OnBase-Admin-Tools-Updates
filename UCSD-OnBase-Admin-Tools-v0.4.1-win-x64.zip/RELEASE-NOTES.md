# Version 0.4.1

AD Groups history now tells you which memberships actually worked. A run
that applies members and then fails its post-write check no longer marks
every person as Failed: only the members the check named stay Failed, and
the rest read OK. Each history row carries the result line for that person
and group, and the CSV export writes one row per action with a Command
Result column, so a real failure is a filter away instead of buried in a
batch summary.

Every AD command now keeps its own evidence. History records the exit code,
start time, duration, the exact script and verification script, and the raw
output PowerShell wrote, and failed rows show that transcript in the row
details. The next time a command misbehaves you can read what happened
instead of reproducing it.

Feedback reports can now carry a diagnostic log. The Feedback dialog offers
a previewable snapshot of the recent application log and the most recent AD
change records - including those command transcripts - before anything is
sent. It goes to the tool team as an attachment, and the dialog says so if
an attachment fails to upload.

If you are still on 0.3.7, this also brings everything from 0.4.0: the
built-in OnBase API onboarding guide on the Credential Setup screen, and
the explicit New Project flow.
