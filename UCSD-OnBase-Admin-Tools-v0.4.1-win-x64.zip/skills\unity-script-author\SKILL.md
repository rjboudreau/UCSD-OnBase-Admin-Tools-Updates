---
name: unity-script-author
description: Draft, revise, and package UCSD OnBase Unity Scripts, including modifying scripts that already exist in OnBase Studio. Use when a prompt points at a unity-scripts brief or package folder, asks to create, fix, modify, or version a Unity Script, or shares an OnBase Studio screenshot such as compile errors. Not for OnBase REST API work or Studio repository administration.
metadata:
  version: "0.11"
  short-description: Author UCSD OnBase Unity Scripts
---

# UCSD Unity Script Author

Turn a plain-language admin goal into an installable Unity Script package:
`script.cs`, `manifest.json`, `runbook.md`, and numbered versions, written to
the output folder named in the brief.

## Session Start

Figure out which entry mode you are in before doing anything else:

1. **Brief handoff (new script).** A `BRIEF.md` exists in the package folder
   and no `script.cs` does. Follow the Workflow below.
2. **Existing package (continue or modify).** The folder already has
   `script.cs` and `versions/`. Read `BRIEF.md`, `answers.md`, the current
   `script.cs`, the newest version note, and the admin's change request; then
   follow "Modifying an Existing Script".
3. **Cold paste (existing script, no package yet).** The admin pastes the
   source of a script that already lives in OnBase Studio. Do NOT treat this
   as a new-script brief. Follow "Modifying an Existing Script" starting at
   the baseline import step, creating the package folder first.

If the working directory is not the package folder, prefer the UCSD Admin
Portal's package root when it exists:
`%LOCALAPPDATA%\OnBaseApiExplorer\unity-scripts\<script-name>\` - the
portal's package viewer reads that root, so packages written there stay
visible to the app. If that root does not exist, ask where the package
folder should live (default: `unity-scripts/<script-name>/` next to the
workspace root). Use one folder consistently for the whole session, and do
not commit package folders to source control.

## Non-Negotiables

- **The brief owns configuration truth.** Document types, keyword types,
  queues, statuses, and form field IDs come from `BRIEF.md` exactly. If a
  required name is missing or ambiguous, ask - never invent or approximate.
  When the goal names configuration only by role ("our template", "the
  completion queue"), ask for the exact name before drafting.
- **Never invent input data contracts.** If the script parses structured
  input (XML, CSV, JSON, fixed-width), ask for a real sample or the exact
  element/field names BEFORE drafting. Do not guess element names, and do
  not design around missing information by relocating configuration into
  the input data unless the admin confirms the data actually carries it.
- **Verify API shapes against the reference layers** (see
  `references/reference-layers.md`), never from memory. If a layer is
  missing, say what is missing and what the admin must generate or capture;
  do not guess signatures.
- **The API catalog outranks every example.** When any example, template, or
  doc page disagrees with the locally generated API catalog, the catalog wins
  (it is version-matched to the installed Studio). Say so when you override
  an example.
- **Classify risk before generating.** Every package is `routine` or
  `destructive` (purge, delete, or mass-update). For destructive scripts:
  state the risk and get explicit confirmation in the conversation BEFORE
  drafting, make the runbook's first deployable step a count/dry-run when
  feasible, and include UT1-vs-PROD warnings plus a PROD-install
  confirmation gate.

## Workflow

For a NEW script (entry mode 1):

1. Read the `BRIEF.md` path from the prompt. Treat its config dictionary,
   environment, risk classification, and output folder as authoritative.
2. Infer the script interface from the described behavior (for example
   `IUnityFormCustomActionEventScript` for form custom actions,
   `IWorkflowScript` for queue-driven batch processing,
   `IExternalAutofillKeysetScript` for external-lookup autofill). Ask one
   clarifying question when the interface or trigger is genuinely ambiguous
   - do not guess between materially different designs.
   Then ask blocking questions for everything the draft depends on that no
   reference layer can answer: every configuration name the goal references,
   the input data contract (a real sample or exact element/field names) when
   structured input is parsed, and the expected queue/lifecycle transition
   behavior. Draft only after the admin answers.
3. Consult `references/reference-layers.md` and the bundled
   `references/sdk-guide.md` for SDK lifecycle and API patterns, then draft
   the package per
   `references/package-format.md`.
4. Write the full package to the brief's output folder. Version 1 for a new
   script; version N+1 (with a plain-language change note) for every
   revision after pasted errors or feedback - never overwrite history.
5. End by telling the admin exactly what to do next in Studio (the runbook
   install steps) and what to paste back (compile errors, screenshots, test
   results).

## Modifying an Existing Script

The pasted code is the baseline of record. Everything the script already
does is working behavior until the admin says otherwise.

1. **Import the baseline first, before discussing the change.** Create the
   package folder if needed. Write the pasted source verbatim to
   `script.cs` and snapshot it as `versions/v001.cs` with a note recording
   provenance: the exact Studio script name, who pasted it, and the date.
   Never "improve" the baseline during import.
2. **Inventory the baseline's failure contract.** List every explicit error,
   guard, and failure path the current code enforces (thrown exceptions,
   required-note checks, validation). Preserve each one unless the admin's
   request explicitly changes it; relaxing a guard is a behavior change that
   must be named in the change note, never done silently.
3. **Pre-flight everything before the first irreversible action.** Any
   validation that can be done up front (note text present, configuration
   values resolve, required names exist) MUST happen before the code stores a
   new revision, deletes, or writes anything. A script must never do half its
   work and then fail; retries would duplicate the completed half.
4. **Read the interface and configuration out of the code.** The implemented
   interface (for example `IWorkflowScript`) and every existing magic string
   are facts, not questions. Extract them into the manifest and the change
   plan. Do not re-ask the admin for names already visible in the code.
5. **Handle multi-artifact changes deliberately.** A real change may span a
   workflow script AND a shared library (or several scripts). Save each
   artifact as its own package file (`script.cs`, `library.cs`, ...), give
   each its own baseline + numbered snapshots, and identify every consumer of
   any shared artifact BEFORE changing its public surface. Document the
   deployment order (libraries publish first, then consumers).
6. **Ask only for what the code and the change request cannot answer**: the
   exact Studio script name (if not given), which environment the script
   currently runs in (UT1, PROD, or both), its required references (the code
   alone does not prove which Add Reference tab entries it needs), and any
   NEW configuration names the change requires. One focused round; a
   modification rarely needs more.
7. **Draft the minimal change.** Modify the existing structure; do not
   rewrite the script to house conventions. Keep the existing logging
   pattern, naming, and layout unless the admin asked for cleanup. New code
   inserted into an existing script should match that script, not a fresh
   template.
8. **Publish version N+1.** Snapshot the baseline before overwriting, write
   the new `script.cs`, bump `manifest.json`, and write a change note that
   says WHAT changed and WHY, keyed to the admin's request. Also update
   `runbook.md` to the modify-in-Studio shape: open the existing script in
   Studio, select-all/paste the new version, add only NEW references, then
   compile and test. A fresh-install runbook is wrong for an existing
   script.
9. **Set risk from the change, not just the script.** A routine script
   modified to delete or mass-update is now destructive: apply the risk gate
   before drafting, same as a new destructive script.
10. **End with the round trip**: exactly what to paste into Studio, what to
   paste back (compile errors, screenshots, test results), and a reminder
   that the UT1 copy is the place to verify before touching PROD.

## Delivering Code to the Admin

The admin's workflow is copy-paste between this chat and OnBase Studio.
Serve that workflow directly:

- **After every version, show the complete paste-ready source.** Print the
  full current file in one fenced code block - never a diff, never a
  fragment, never "see the saved file." For multi-artifact changes, print
  each changed artifact under its own heading. Also state where it was saved
  so the admin can find it later.
- **Ask for screenshots of Studio errors.** Studio compile errors are not
  easily copyable as text. When a compile or test fails, explicitly invite
  the admin to paste a SCREENSHOT of the error pane instead of retyping it.
  When one arrives, transcribe the exact error text (file, line, code, and
  message) back in your reply before proposing a fix, so nothing is
  misread.
- **Diagnose an iteration before reprinting code.** When the admin reports a
  compile error, test failure, or behavior concern, first explain in plain
  language what happened and where: for example, "Line 45 passes the whole
  `Document` object where the API expects a document ID." Map Studio's file
  and line to the current package source,
  name the mistake, and state the intended fix. If the reported line does not
  match the package source, say so and ask for a screenshot instead of
  guessing.
- **Pace iterations with an understanding checkpoint.** After the diagnosis,
  ask whether it matches what the admin sees before continuing when the
  error is ambiguous or the behavior requires a design decision. For an
  obvious mechanical compile error, the diagnosis, fix, and complete updated
  source may appear in the same message. After any revision, resume Studio at
  the correct checkpoint (usually Source or Clean Build) instead of
  restarting completed setup steps.
- **Pace every interactive Studio walkthrough by checkpoint.** Do not dump
  the whole runbook into chat. Send one small checkpoint at a time, name the
  exact screen the admin should reach, and wait for them to confirm (or paste
  a screenshot) before continuing. Bundle only trivial clicks that lead
  directly to the next named screen; separate consequential actions such as
  granting permissions, pasting source, adding references, publishing, and
  cache resets. Give the complete runbook at once only when the admin
  explicitly asks for it.
- **Walk the admin through the editor ribbon sequence** (see
  `references/studio-guide.md`): **Save** (yellow margin bars or a tab
  asterisk mean unsaved; green means saved), **Build** until the error pane
  is clean, then **Save & Publish**, which publishes the version and sets
  it ACTIVE (verify in Properties > Versions). After publishing, accept the
  cache-reset prompt so consumers load the modified script. The runbook must
  name these buttons and the cache reset at the exact step where they happen.

## House Conventions

- **Logging**: `app.Diagnostics.Write` with `=== SCRIPT START ===`,
  `=== SCRIPT COMPLETE ===`, and `=== SCRIPT ERROR ===` markers;
  `WriteIf(DiagnosticsLevel.Verbose)` for detail. Never a silent
  `catch { }` - log and continue, or log and rethrow at entry points.
- **Configuration**: every magic string (document types, keyword types,
  queues, statuses, field IDs) lives in a `Config` class or constants block
  at the top of the script.
- **Secrets**: only in Unity Configuration items, never in code; list each
  required item in the manifest with provisioning notes.
- **Concurrency**: lock documents (`LockDocument` plus status checks) and
  use status-claim patterns when multiple instances can run; cap batch
  sizes and retries.
- **Idempotency**: tolerate re-triggered events - detect duplicates before
  acting, at memory and repository level where applicable.
- **Libraries**: prefer proven in-house script libraries over reinventing,
  but only ones the brief or reference catalog lists as maintained. The
  `Logger (version 1)` library is NOT for new scripts.
- **Modifications**: the existing script's conventions win. House
  conventions govern new scripts; changes to an existing script preserve its
  established structure, naming, and logging so the diff the admin reviews in
  Studio is as small as the request allows.
