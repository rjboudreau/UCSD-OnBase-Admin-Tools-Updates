# Unity SDK Guide

This guide is the narrative SDK layer bundled with the skill. Use it for
lifecycle, patterns, and diagnostics. For every exact signature, member name,
or overload, consult the version-matched API catalog first; it outranks this
guide and every example.

## Application and Entry Point

Unity Script entry points receive a connected `Hyland.Unity.Application`
object. The host has already opened the session; scripts do not authenticate,
dispose the application, or manage its lifetime.

Common responsibilities:

- Resolve repository objects through the application's service properties
  (`Document`, `Workflow`, `UnityForm`, `Keyword`, and related services).
- Treat event arguments as the trigger context. Read IDs, current values, and
  trigger-specific results from them instead of reconstructing state.
- Keep the entry method small: validate, claim work, perform one bounded unit,
  log completion, and return.

## Common Hook Families

- **Workflow scripts** run for a workflow event. They usually inspect the
  document or queue context, load keywords, make a narrow repository change,
  and transition the document or queue item. They must tolerate re-delivery.
- **Unity Form custom action scripts** run when a configured form action
  executes. They receive form instance data and may return result data through
  the event arguments. Validate form field IDs against the brief, never from
  an example.
- **External lookup and data-set scripts** supply data to an OnBase feature.
  They should fail closed on malformed input and never mutate unrelated data.
- **Client and lifecycle event scripts** can be powerful and destructive. Apply
  the destructive-script gate before drafting.

## Retrieval and Modification Pattern

1. Resolve the exact configuration object by name or ID from the brief.
2. Retrieve the current entity and load the data the script will change.
3. Claim the work when concurrent instances are possible: lock the document or
   use a status/keyword claim before acting.
4. Modify through the API's modifier object, not by writing raw values to an
   unrelated object.
5. Save or transition once, then log the resulting identifier and outcome.

For keyword work, load the document's current keywords before writing. Use the
keyword type's factory method shown in the API catalog, then persist through
the document modifier. Do not assume numeric, alphanumeric, date, or list
keyword conversion rules; check the catalog and the brief's exact keyword type.

For workflow transitions, retrieve the target queue or lifecycle state by exact
name and transition the specific document or work item. Re-check its current
state immediately before changing it so a retried event cannot skip validation.

## Batch and Concurrency

- Bound every batch with a maximum count and a stable sort or query.
- Process one document or work item per loop iteration and catch at that scope.
- Lock documents before changing shared state, and release through the API's
  documented save/commit path.
- Use a status or keyword claim for queue work when more than one AppServer can
  execute the same event.
- Make the action idempotent: detect already-processed records before acting.
- Never rely on the absence of an exception as proof that the repository changed.

## Diagnostics

Use `app.Diagnostics.Write` with the house markers:

```csharp
app.Diagnostics.Write("=== SCRIPT START ===");
app.Diagnostics.WriteIf(DiagnosticsLevel.Verbose, "...");
app.Diagnostics.Write("=== SCRIPT ERROR ===");
app.Diagnostics.Write("=== SCRIPT COMPLETE ===");
```

Log the trigger identifier, resolved configuration names, count or result, and
the final state. At entry points, either log and continue safely or log and
rethrow; never use an empty catch. An error that leaves partial work must be
visible in diagnostics and in the runbook's troubleshooting table.

## Input Contracts

Scripts that parse XML, CSV, JSON, fixed-width text, or another structured
format require a real sample or exact element and field names before drafting.
Do not infer names from examples or move configuration into the parser. For XML,
prefer explicit namespace-aware parsing. For delimited text, define the quote,
escape, and header behavior in the brief and preserve it in the manifest.

## Environment and Risk

- Draft and verify in UT1 first. PROD requires explicit admin confirmation.
- Destructive scripts state the risk before drafting, count or dry-run first
  when feasible, and carry a PROD confirmation gate in the runbook.
- Configuration names, references, and permissions can differ by environment.
  The brief is the source of truth; ask when it is incomplete.

## API Catalog Boundary

This guide deliberately does not duplicate every API signature. When this guide
and the API catalog disagree, the catalog wins. If a catalog type page is
missing, say what is missing and ask for the exact behavior; do not invent a
member or overload.
