# OnBase Studio Guide for Unity Scripts

This is the click-by-click layer for the admin's last mile. Steps marked
**[NEEDS SCREENSHOT]** are provisional: confirm the exact menu labels and
dialog contents before quoting them in a runbook, and describe them from the
admin's own screenshots whenever available.

## The Editor Ribbon: Save, Build, Save & Publish

Every script edit, new or modified, finishes through the same three buttons
in the editor's **Project** ribbon group
(`screenshots/editor-ribbon-project-group.png`):

1. **Save** - pasting alone changes nothing. Click Save, then confirm it
   took: the tab title loses its asterisk ("... Library v26*" means
   unsaved) and the change bars in the left margin turn from yellow
   (unsaved) to green (saved)
   (`screenshots/editor-saved-state-markers.png`).
2. **Build** - compiles and populates the error pane. Fix errors (or paste
   a screenshot of them back to the agent) and repeat Save + Build until it
   builds clean. Never publish a script that does not build.
3. **Save & Publish** - saves any remaining edits, publishes the version,
   and sets it ACTIVE. Verify in Properties > Versions that the new version
   shows Active while previously published versions show Published
   (`screenshots/library-versions-panel.png`).
4. **Cache reset** - Studio prompts for a cache reset after publishing a
   script. Accept it; skipping it can leave consumers running the
   cached previous version during verification.

## Guided Pacing and Checkpoints

Use this pacing for every interactive Studio walkthrough, whether the admin
is creating a first script or modifying a long-standing one:

- Send ONE checkpoint per message. Name the exact screen or state to reach,
  the action to take there, and what to check before replying.
- Bundle only simple, consecutive clicks that lead directly to the next
  named screen (for example: open the **Unity Scripts** ribbon tab, then
  click **Script**). Keep consequential actions alone: granting Modify,
  pasting source, adding a reference, publishing, or accepting a cache
  reset.
- Ask the admin to check in with a short confirmation such as "I'm on the
  Name step" or a screenshot. Do not send the next step until the current
  checkpoint is confirmed.
- If the admin explicitly asks for the full instructions, give the complete
  runbook instead and offer to step through checkpoints only if something
  goes wrong.

## Iterating on Errors and Feedback

Treat every compile error, failed test, or user-feedback message as an
iteration with its own pacing:

1. **Read back the evidence exactly.** For a compile error, quote the file,
   line, error code, and message from the screenshot before interpreting it.
   For a test or user report, restate the observed behavior in one plain
   sentence.
2. **Locate the source.** Map the reported line to the current package file.
   Then explain the mistake in simple terms: "Line 45 passes the whole
   document where the API expects the document ID." Never make the admin
   infer which line or method caused the problem.
3. **Name the fix.** Say what will change and why, in the same plain
   language. Distinguish a code correction from a configuration change; a
   missing reference, note type, or permission is not fixed by editing the
   script.
4. **Check understanding when it matters.** If the diagnosis is ambiguous or
   the feedback changes behavior, ask the admin to confirm it matches what
   they see before drafting the next version. For an obvious mechanical
   error, diagnose, correct, and print the complete updated source in one
   reply.
5. **Resume at the right checkpoint.** A source-only correction resumes at
   the Source checkpoint. A missing reference resumes at the References
   checkpoint. Do not make the admin repeat wizard, permissions, or trigger
   steps that already succeeded.
6. **Record the iteration.** Snapshot the prior version, publish version
   N+1, and write a change note that includes the evidence, the affected
   line or method, the diagnosis, and the correction.

## Creating a New Unity Script from Scratch

Wizard screenshots live in `screenshots/` (ribbon entry, name step, script
type picker, code permissions, summary) - view them when guiding an admin
through these screens.

Use these checkpoints when guiding the admin interactively:

1. **UT1 connection checkpoint:** open OnBase Studio connected to UT1. The
   wizard title shows the connected datasource (for example "Create Unity
   Script (obucsdut1)") - verify it says UT1 before creating anything.
2. **Wizard entry checkpoint:** on the ribbon, open the **Unity Scripts**
   tab and click **Script** (in the New group). Confirm the admin reaches
   the Name step.
3. **Name step checkpoint:** enter the script's exact Studio display name
   (this becomes the package's `studioName`), an optional description, and
   Language **C#** (never Visual Basic for our packages). Confirm the values
   before advancing.
4. **Script type checkpoint:** pick the interface the package manifest names. The
   list is categorized (Application Enabler, Client Events, Document
   Composition, Document Events, ECommerce, Enterprise Integration Server,
   Indexing Events, Plug-ins, Scanning Events, Scheduler Events, Unity
   Forms, Workflow, WorkView); use the **Find** box to search the interface
   name. Next stays disabled until a type is selected. Confirm the selected
   interface before advancing.
5. **Code permissions checkpoint - CRITICAL:** add a User Group (for example
   `OB_ALL_Super_Admin` from the dropdown) and grant BOTH **View** and
   **Modify**. A script created without a user group holding Modify cannot
   be edited afterward - the admin will be locked out of their own script.
   Never skip this step or click through with an empty permissions grid.
   Have the admin confirm the grid shows View + Modify before advancing.
6. **Summary checkpoint:** confirm Name, Type: Script, and Script Interface
   match the manifest, then click **Finish**. Confirm the generated editor
   opens before pasting anything.
7. **Source checkpoint:** select-all in the generated template and paste the
   package's `script.cs`, then click **Save** and confirm the saved-state
   markers.
8. **References checkpoint:** add the references the manifest lists - see
   Adding References below. Confirm each tab, exact name, and version before
   continuing.
9. **Clean Build checkpoint:** click **Build**. A clean build is the
   checkpoint; if errors appear, stop and process the error screenshot
   before continuing.
10. **Publish checkpoint:** click **Save & Publish**, accept the cache-reset
   prompt, and verify the new version is Active in Properties > Versions.
11. **Trigger checkpoint:** attach/configure the trigger (workflow queue,
   life cycle, form action,
   or client event, depending on the interface). **[NEEDS SCREENSHOT: one
   example per interface family, starting with workflow]**. Confirm the
   trigger configuration before starting the UT1 verification plan.

## Modifying an Existing Script in Place

1. Open the script by its EXACT Studio name (similar names are common -
   confirm against `manifest.json` `studioName`).
2. Confirm the open source matches the package baseline before overwriting
   (check version number and last-modified date).
3. Select-all and paste the new source, then Save and Build until clean -
   pasting alone changes nothing (see The Editor Ribbon above).
4. Add only NEW references (see below); existing references survive.
5. For a script LIBRARY: click **Save & Publish** (publishes the version
   and sets it Active), then verify the new version shows Active in
   Properties > Versions. A library whose new version is not Active is the
   most common failed deploy - consumers keep running the old Active
   version.

## Adding References

Studio's Add Reference dialog has three tabs, and the manifest pins each
reference as `{tab, name, version}`:

- **Imported Assemblies** - external DLLs stored in the Unity repository.
  Versions matter; duplicates at multiple versions exist.
- **System Assemblies** - GAC-only on the AppServer, NOT in the Unity
  repository. A system reference is an environment dependency; note the GAC
  requirement in the runbook.
- **Unity Script Libraries** - published Unity scripts usable as libraries.
  Record the name and the publish version.

Derive required references from the APIs the script actually uses. Common
mappings:

| APIs used | Reference (tab) |
| --- | --- |
| GDI+ image drawing (`Bitmap`, `Graphics`, `Font`) | System.Drawing (System Assemblies) |
| Zip handling (`ZipArchive`) | System.IO.Compression (System Assemblies) |
| PDF stamping via `pra.ucsd.edu.autosignature` | the autosignature imported assembly + iTextSharp (Imported Assemblies) |
| In-house stampers/roles/notifications | the named Unity Script Library at its publish version |

Always confirm exact display names and versions against the admin's own Add
Reference dialog - the seed catalog's version digits are OCR-derived and
unverified. The Imported Assemblies tab is captured; the System Assemblies
and Unity Script Libraries tabs still need screenshots.

### Finding the Exact Reference Row

The Imported Assemblies tab is shown in
`screenshots/add-reference-imported-assemblies.png`. Guide the admin through
it as one simple checkpoint:

1. Confirm the correct tab is selected: **Imported Assemblies**,
   **System Assemblies**, or **Unity Script Libraries**.
2. On Imported Assemblies, confirm **Show Active Assemblies Only** is
   checked.
3. Find the row whose **Display Name** and **Version** exactly match the
   manifest entry. The dialog also shows ID, Assembly Name, Date Modified,
   Runtime Version, Status, and Description; use those columns to
   disambiguate, but the manifest's display name and version decide the
   selection.
4. If multiple rows are still ambiguous, or the manifest name/version is not
   visible, stop and ask for a screenshot. Do not guess between near-duplicate
   assemblies or versions.
5. Check the exact row, click **OK**, and confirm the reference appears in
   the script's reference list before building.

## Common Admin Mistakes

Call these out in the runbook at the exact step where each can happen:

1. **Pasting without saving** - yellow change bars and a tab asterisk mean
   unsaved; green bars mean saved. The edit is lost or never takes effect.
2. **Editing the wrong script** - similar names (COI vs Chancellor variants);
   always verify the exact Studio name.
3. **Publishing a library without its new version ACTIVE** - verify
   Properties > Versions after Save & Publish; consumers keep using the old
   Active version and the change silently does not ship.
4. **Stale reference version** - the script compiles against an older
   published library version; repoint the reference and recompile.
5. **Deploying consumers before libraries** - publish the library first,
   activate it, then paste/compile the calling script.
6. **Skipping the post-publish cache reset** - accept Studio's cache-reset
   prompt after publishing; otherwise a clean deploy can still test stale,
   cached script code.
7. **Skipping prerequisites** - note types / Unity Configuration items /
   rights that must exist before the test can pass.
8. **Creating a script without granting a user group Modify permission** -
   the admin cannot edit the script they just created.

## Screenshots to Request from the Admin

When improving this guide, ask for:

1. The System Assemblies and Unity Script Libraries Add Reference tabs.
2. A workflow configuration screen showing where a script is attached.
3. The compile error pane (so error screenshots are recognized instantly).

Captured (in `screenshots/`): the editor ribbon's Project group (Save /
Save & Publish / Build), the saved-state markers (yellow unsaved vs green
saved, tab asterisk), the library Properties > Versions panel, and the
Imported Assemblies Add Reference tab.
