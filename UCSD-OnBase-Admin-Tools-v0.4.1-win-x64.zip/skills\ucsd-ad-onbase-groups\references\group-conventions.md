# OnBase AD Group Conventions

## Location

All OnBase groups live in:

```text
OU=OnBase,OU=Groups,OU=ITS,DC=AD,DC=UCSD,DC=EDU
```

## Group Types

OnBase AD groups come in families, all inside the OnBase OU (counts
measured 2026-10-07): DocType (241), SecurityKeyword (196), Workflow
(70), ScanQueue (43), Functional (35), User-Group-Admin (32),
Notification (6), plus a long tail of privilege groups (Reporting,
FileCabinet, NoteType, ShareForm, StatusView, PDFPop, and others).

House structure for onboarding a user: every user ALWAYS gets a
Functional group and at least one DocType group; Workflow,
Notification, ScanQueue, and SecurityKeyword groups are optional
additions on top. Access levels come in four standard grades —
ViewOnly, Standard, Power, DeptAdmin. The base functional level groups
are `OB_Functional_Lvl1_ViewOnlyUsers` through
`OB_Functional_Lvl4_DepartmentalAdmin`; DocType groups carry a level
suffix. Naming drifts across areas (Standard vs StandardUsers, ViewOnly
vs ViewOnlyUsers vs ReadOnly, PowerDelete, DepartmentalAdmin) — query
the area's existing groups and follow the local suffix.

| Type | Name pattern | Category/Scope | Description |
|---|---|---|---|
| SecurityKeyword | `OB_SecurityKeyword_X_HR_[VCAA-UNIT]_[DEPT-ABBR]` | Global Security | Optional; set only if the request specifies one |
| ScanQueue | `OB_ScanQueue_X_HR_[VCAA-UNIT]` | Global Security | Optional; set only if the request specifies one |
| User-Group-Admin | `OB_X_HR_[VCAA-UNIT]_[DEPT-ABBR]_User-Group-Admin` | DomainLocal Security | `Managers who have the ability to add users to the X_HR_[VCAA-UNIT]_[DEPT-ABBR] Groups` |

When a unit has sub-department keyword groups, use one SecurityKeyword group per department abbreviation (for example a BIOSCI unit with CDB, EBE, MB, and NB departments). Do not put raw numeric department codes in group names — existing VCAA keyword groups use abbreviations.

Before creating anything, confirm the local convention by querying similar existing groups:

```powershell
Get-ADGroup -Filter "Name -like 'OB_SecurityKeyword_X_HR_VCAA*'" |
  Sort-Object Name |
  Select-Object Name, GroupScope, GroupCategory
```

If existing groups contradict the patterns above, follow the existing groups and note the difference to the user.

## Department Code Lookup

1. Check AD first — department code descriptions often appear on `KR_Approvers_000XXX` groups, where `XXX` is the 3-digit code.
2. If AD has no match, look up the code on the Blink Ecotime department codes page:
   https://blink.ucsd.edu/sponsor/hr/divisions-units/data/hr-payroll/timekeeping/ecotime/department-codes.html
3. Department codes in the 200-range are academic divisions; 600-range codes are Biological Sciences sub-departments.

## Creation Commands

Draft these, get approval, then run:

```powershell
New-ADGroup -Name "OB_SecurityKeyword_X_HR_VCAA_CDB" `
  -GroupCategory Security -GroupScope Global `
  -Path "OU=OnBase,OU=Groups,OU=ITS,DC=AD,DC=UCSD,DC=EDU"

New-ADGroup -Name "OB_ScanQueue_X_HR_VCAA_BIOSCI" `
  -GroupCategory Security -GroupScope Global `
  -Path "OU=OnBase,OU=Groups,OU=ITS,DC=AD,DC=UCSD,DC=EDU"

New-ADGroup -Name "OB_X_HR_VCAA_BIOSCI_CDB_User-Group-Admin" `
  -GroupCategory Security -GroupScope DomainLocal `
  -Path "OU=OnBase,OU=Groups,OU=ITS,DC=AD,DC=UCSD,DC=EDU"

Set-ADGroup -Identity "OB_X_HR_VCAA_BIOSCI_CDB_User-Group-Admin" `
  -Description "Managers who have the ability to add users to the X_HR_VCAA_BIOSCI_CDB Groups"
```

When creating several groups, loop over an approved list and print one OK/FAILED line per group so partial failures are visible.

## Verification

After creation, verify each group:

```powershell
Get-ADGroup -Identity "OB_ScanQueue_X_HR_VCAA_BIOSCI" -Properties Name, GroupScope, GroupCategory, Description
```

Confirm the name, scope (Global vs DomainLocal), category (Security), and description match the approved plan before reporting success.
