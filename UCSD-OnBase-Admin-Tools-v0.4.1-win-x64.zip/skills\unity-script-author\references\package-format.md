# Script Package Format

One folder per script (or script family) at the brief's output folder
(`unity-scripts/<script-name>/` by default):

- `script.cs` - the current version, complete and paste-ready.
- additional artifacts when a change spans a shared library or several
  scripts (for example `library.cs`) - each is a current version of one
  Studio artifact, complete and paste-ready.
- `manifest.json` - machine-readable interface and requirements.
- `runbook.md` - click-by-click Studio install instructions.
- `versions/` - numbered snapshots with change notes.
- `BRIEF.md` - the app-written input; read it, never modify it.

For multi-artifact packages, name snapshots per artifact
(`v001-script.cs`, `v001-library.cs`, `v002-script.cs`, ...) and record the
deployment order in the runbook: publish and activate libraries first, then
paste and compile their consumers.

## manifest.json

```json
{
  "name": "kebab-case-script-name",
  "studioName": "Exact display name in OnBase Studio",
  "version": 1,
  "interface": "Hyland.Unity.IWorkflowScript",
  "targetFramework": "net48",
  "risk": "routine",
  "references": [
    { "tab": "Unity Script Libraries", "name": "Exact display name", "version": "104" }
  ],
  "configurationItems": [
    { "name": "ItemName", "purpose": "What it holds", "provisionedBy": "Role or team" }
  ],
  "scriptLibraryDependencies": ["Maintained library names"],
  "status": "Draft"
}
```

`studioName` is required for packages created by importing an existing
script (the Studio display name often differs from the folder name) and
absent for new scripts.

Reference rules (Studio's Add Reference dialog has three tabs, and every
manifest reference is `{tab, name, version}`):

- **Imported Assemblies** are versioned in the Unity repository - pin exact
  versions; duplicates at multiple versions exist.
- **System Assemblies** are GAC-only on the AppServer and NOT stored in the
  Unity repository - flag them as environment dependencies and note the GAC
  requirement in the runbook.
- **Unity Script Libraries** are published scripts usable as libraries -
  record the name and publish version; Studio keeps no change history, so
  package version notes supply it for our own scripts.
- Add Reference steps in the runbook must name the tab and the exact
  version.

## runbook.md

Required sections:

1. **Prerequisites** - references (tab + version), configuration items and
   who provisions them, permissions, environment warnings.
2. **Studio install** - click-by-click: create the script type named by the
   interface, paste `script.cs`, add references, build, publish, and
   attach/configure the trigger. Group the steps by named checkpoint, and
   give each checkpoint an expected screen or result the admin can confirm.
   Reference steps must say which Add Reference tab to open and how to match
   the manifest's exact display name and version.
3. **Verification** - the UT1 test plan with concrete sample data and
   pass/fail criteria; for destructive scripts the first deployable step is
   a count/dry-run when feasible.
4. **Troubleshooting** - table of likely errors and fixes.
5. **Promotion** - the `.expk` export/import checklist (UT1 export to PROD
   import), UT1-vs-PROD warnings, and the PROD-install confirmation gate
   for destructive scripts.

For a package whose script already exists in Studio, replace the "Studio
install" section with a **modify-in-Studio** section: open the existing
script by its exact Studio name, select-all/paste the new `script.cs`, add
only NEW references (tab + version), then Save, Build until clean, and
Save & Publish (accepting the cache-reset prompt) before running the
verification plan. Never instruct the admin to create a second script.

## versions/

- `v001.cs` plus `v001.md` (change note) - snapshot each published version.
- For an IMPORTED existing script, `v001` is the baseline: the pasted source
  verbatim, with `v001.md` recording provenance (exact Studio script name,
  who pasted it, date, and which environment it currently runs in). The
  first modification is version 2.
- Every revision after pasted errors or feedback publishes version N+1:
  snapshot the current file BEFORE overwriting, write the new current
  `script.cs`, bump `manifest.json` `version`, and add a plain-language
  change note (what changed and why, keyed to the error or feedback). Include
  the evidence, affected line or method, diagnosis, and correction so the
  iteration can be reviewed later without reconstructing the conversation.
- Never modify a snapshot. Reverting to an older version is itself a new
  version with a note saying so.

## Status Badges

`Draft` -> `Compiles` -> `Installed in UT1` -> `UT1-verified` -> `Promoted`.

The agent sets `Draft`. Advance `Compiles` only with evidence (the admin
reports a clean compile); UT1 and PROD milestones come from admin
attestation, never assumptions.
