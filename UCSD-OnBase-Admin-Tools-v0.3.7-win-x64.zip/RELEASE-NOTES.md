# Version 0.3.7

AD Groups now explains its authorization model before you approve changes:
every command runs with your signed-in Windows account, and AD enforces
the OnBase OU and group rights command by command. The review no longer
implies that a dry run proves real-run permissions; -WhatIf validates the
commands without changing AD.

When AD denies a command, the result and history now say "Permission
denied" and name the right to request, such as Create Group rights on the
OnBase OU or Modify Membership / Write Members rights on the affected AD
group. Other failures keep their original error details.
